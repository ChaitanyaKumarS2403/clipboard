import { StateGraph, Annotation } from "@langchain/langgraph";

// The "New" way: Define state using Annotation.Root
const GraphAnnotation = Annotation.Root({
    messages: Annotation({
        // This 'reducer' ensures messages are appended to the list, not overwritten
        reducer: (left, right) => left.concat(right),
        default: () => [],
    }),
});

export function createAgent(llm) {
    // Pass the Annotation object instead of a plain state object
    const graph = new StateGraph(GraphAnnotation);

    graph.addNode("chat", async (state) => {
        const response = await llm.invoke(state.messages);
        return {
            messages: [response] // The reducer will handle adding this to the existing list
        };
    });

    graph.addEdge("__start__", "chat");
    graph.addEdge("chat", "__end__");

    return graph.compile();
}