import { useState, useEffect, useRef } from 'react';
import './App.css';

function App() {
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef(null);

  // Auto-scroll to bottom whenever messages change
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const sendMessage = async (e) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMsg = { role: 'user', text: input };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await fetch('http://localhost:3001/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: [input] }),
      });
      const data = await response.json();
      setMessages(prev => [...prev, { role: 'ai', text: data.reply }]);
    } catch (err) {
      setMessages(prev => [...prev, { role: 'ai', text: "Connection error. Is the server running?" }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="chat-container">
      <header className="chat-header">
        <div className="status-dot"></div>
        <span style={{color: 'white', fontWeight: '600'}}>Ollama ChatBot</span>
      </header>
      
      <div className="chat-window" ref={scrollRef}>
        {messages.length === 0 && (
          <div style={{textAlign: 'center', color: 'var(--text-dim)', marginTop: '20%'}}>
            <p>Hello! How can I help you today?</p>
          </div>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`msg-box ${m.role}`}>
            {m.text}
          </div>
        ))}
        {isLoading && (
          <div className="msg-box ai" style={{opacity: 0.7}}>
            Gemma is thinking...
          </div>
        )}
      </div>

      <form onSubmit={sendMessage} className="chat-input-area">
        <input 
          value={input} 
          onChange={(e) => setInput(e.target.value)} 
          placeholder="Type your message..."
          autoFocus
        />
        <button type="submit" disabled={isLoading}>
          {isLoading ? '...' : 'Send'}
        </button>
      </form>
    </div>
  );
}

export default App;